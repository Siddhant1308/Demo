package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.example.demo.models.User;
import com.example.demo.repository.UserRepository;

import java.util.List;

@Controller
public class StudentController {

    @Autowired
    private UserRepository userRepo;

    @GetMapping("/")
    public String showForm() {
        return "form";  // form.jsp
    }
    
    @GetMapping("/welcome")
    public String showTable(Model model) {
    	  List<User> users = userRepo.findAll();
          model.addAttribute("userList", users);
        return "welcome";  
    }
    @PostMapping("/delete")
    public String deleteUser(@RequestParam Integer id,Model model) {
    	  userRepo.deleteById(id);
    	  List<User> users = userRepo.findAll();
          model.addAttribute("userList", users);
    	return "welcome";
    }

    @PostMapping("/welcome")
    public String showWelcome(@RequestParam String username,
                              @RequestParam String email,
                              @RequestParam String eventName,
                              Model model) {
        try {
            // Save new user
            User u =new User(username,email,eventName);
            userRepo.save(u);
            System.out.println("Saved: " + u);

            // Load all users from DB
            List<User> users = userRepo.findAll();
            model.addAttribute("userList", users);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "welcome";  // welcome.jsp
    }
}
